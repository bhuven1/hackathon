package com.laureen.expirydatetracker;

public class ScanActivity {

}
